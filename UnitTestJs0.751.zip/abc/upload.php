﻿<?php
echo '{"abc":"abc","bdc":"bbb"}';